<?php

// MongoDB connection configuration
$mongo_connection_string = "mongodb://localhost:27017";

?>

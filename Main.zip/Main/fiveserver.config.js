// fiveserver.config.js
module.exports = {
    php: "D:\\Programs\\XAMPP\\php\\php.exe"   // Windows
}